-- WoW 3.3.5 / Ascension. No external libraries or default-frame hooks.
local ADDON = "RangerAdvantage"
local ADVANTAGE_ID = 804329
local MAX_POINTS = 5
local db, meter, label, counter
local segments, glows = {}, {}
local ART = "Interface\\AddOns\\RangerAdvantage\\Media\\"
local lastPoints, gainTime, pulseTime = 0, 0, 0
local atFull = false
local preview = false
local previewTime = 0
local driver = CreateFrame("Frame")

local function Say(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cff70dd88Ranger Advantage:|r " .. message)
end

local function ReadAura()
    local localized = GetSpellInfo(ADVANTAGE_ID)
    local best
    for _, filter in ipairs({"HELPFUL", "HARMFUL"}) do
        for i = 1, 40 do
            local name, _, _, count, _, _, _, _, _, _, spellID = UnitAura("player", i, filter)
            if not name then break end
            if spellID == ADVANTAGE_ID or name == "Advantage" or (localized and name == localized) then
                -- Non-stacking auras report zero even when one is present.
                best = math.max(best or 0, (count and count > 0) and count or 1)
            end
        end
    end
    return best
end

local function ReadPoints()
    local aura = ReadAura()
    if aura ~= nil then return aura, "Advantage aura" end
    return (GetComboPoints("player", "target") or 0), "combo-point API"
end

local function Draw(points)
    points = math.max(0, math.floor(tonumber(points) or 0))
    counter:SetText(points .. " / " .. MAX_POINTS)
    label:SetText(preview and "ADVANTAGE  [TEST]" or "ADVANTAGE")
    if points > lastPoints then gainTime = 0.35 end
    lastPoints = points
    atFull = points >= MAX_POINTS
    counter:SetTextColor(atFull and 1 or 0.83, atFull and 0.83 or 0.89, atFull and 0.40 or 0.82)
    for i = 1, MAX_POINTS do
        local active = i <= points
        segments[i]:SetTexture(ART .. (active and (atFull and "gem-gold" or "gem-green") or "gem-empty"))
        glows[i]:SetVertexColor(atFull and 1 or 0.25, atFull and 0.72 or 1, atFull and 0.22 or 0.55)
        if not active then glows[i]:SetAlpha(0) end
    end
end

-- CoA exposes Ranger as RANGER (class ID 21). Accept the short token
-- used by some custom UI integrations as well.
local function IsRanger()
    local name, token, classID = UnitClass("player")
    token = string.upper(token or "")
    return token == "RANGER" or token == "RANG" or name == "Ranger" or classID == 21
end

local function UpdateVisibility()
    local visible = db.enabled and IsRanger()
    if visible then
        meter:Show()
    else
        if meter.dragging then
            meter:StopMovingOrSizing()
            meter.dragging = false
            local point, _, relativePoint, x, y = meter:GetPoint(1)
            db.point, db.relativePoint, db.x, db.y = point, relativePoint, x, y
        end
        meter:Hide()
        if GameTooltip:GetOwner() == meter then GameTooltip:Hide() end
    end
    return visible
end

local function Refresh()
    if not meter or not UpdateVisibility() then return end
    local points
    if preview then points = math.floor(previewTime) % (MAX_POINTS + 1)
    else points = ReadPoints() end
    Draw(points)
end

local function SavePosition()
    local point, _, relativePoint, x, y = meter:GetPoint(1)
    db.point, db.relativePoint, db.x, db.y = point, relativePoint, x, y
end

local function ApplyPosition()
    meter:ClearAllPoints()
    meter:SetScale(db.scale)
    meter:SetPoint(db.point, UIParent, db.relativePoint, db.x, db.y)
end

local function SetLocked(locked)
    if meter.dragging then
        meter:StopMovingOrSizing()
        meter.dragging = false
        SavePosition()
    end
    db.locked = locked
    -- Locked meters pass clicks through to the world.
    meter:EnableMouse(not locked)
    if GameTooltip:GetOwner() == meter then GameTooltip:Hide() end
end

local function Build()
    meter = CreateFrame("Frame", "RangerAdvantageMeter", UIParent)
    meter:SetWidth(218)
    meter:SetHeight(64)
    meter:SetFrameStrata("MEDIUM")
    meter:SetMovable(true)
    meter:SetClampedToScreen(true)
    local panel = meter:CreateTexture(nil, "BACKGROUND")
    panel:SetAllPoints(meter)
    panel:SetTexture(ART .. "panel")
    label = meter:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("TOPLEFT", 17, -10)
    label:SetFont("Fonts\\FRIZQT__.TTF", 10, "")
    label:SetShadowOffset(1, -1)
    label:SetTextColor(0.78, 0.74, 0.53)
    counter = meter:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    counter:SetPoint("TOPRIGHT", -17, -10)
    counter:SetFont("Fonts\\FRIZQT__.TTF", 11, "")
    counter:SetShadowOffset(1, -1)
    for i = 1, MAX_POINTS do
        local x = 35 + (i - 1) * 37
        local glow = meter:CreateTexture(nil, "BORDER")
        glow:SetWidth(50)
        glow:SetHeight(50)
        glow:SetPoint("CENTER", meter, "BOTTOMLEFT", x, 24)
        glow:SetTexture(ART .. "glow")
        glow:SetBlendMode("ADD")
        glow:SetAlpha(0)
        glows[i] = glow
        local segment = meter:CreateTexture(nil, "ARTWORK")
        segment:SetWidth(30)
        segment:SetHeight(30)
        segment:SetPoint("CENTER", meter, "BOTTOMLEFT", x, 24)
        segments[i] = segment
    end
    meter:RegisterForDrag("LeftButton")
    meter:SetScript("OnDragStart", function(self)
        if not db.locked then
            self:StartMoving()
            self.dragging = true
        end
    end)
    meter:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        self.dragging = false
        SavePosition()
    end)
    meter:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Ranger Advantage", 0.44, 0.87, 0.53)
        GameTooltip:AddLine("Left-drag to move. /radv lock to lock.", 1, 1, 1)
        GameTooltip:AddLine("/radv for commands.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    meter:SetScript("OnLeave", function() GameTooltip:Hide() end)
    ApplyPosition()
    SetLocked(db.locked)
    Refresh()
end

driver:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON then return end
        if type(RangerAdvantageDB) ~= "table" then RangerAdvantageDB = {} end
        db = RangerAdvantageDB
        local anchors = {CENTER=true, TOP=true, BOTTOM=true, LEFT=true, RIGHT=true,
            TOPLEFT=true, TOPRIGHT=true, BOTTOMLEFT=true, BOTTOMRIGHT=true}
        if not anchors[db.point] or not anchors[db.relativePoint] then
            db.point, db.relativePoint, db.x, db.y = "CENTER", "CENTER", 0, -150
        end
        db.x, db.y = tonumber(db.x) or 0, tonumber(db.y) or -150
        db.scale = math.max(0.5, math.min(3, tonumber(db.scale) or 1))
        db.enabled = db.enabled ~= false
        db.locked = db.locked == true
        Build()
        self:UnregisterEvent("ADDON_LOADED")
        if IsRanger() then
            Say(db.enabled and "Loaded. /radv off to hide; /radv for commands." or "Disabled. /radv on to enable.")
        end
    elseif db then
        if event == "UNIT_AURA" and arg1 ~= "player" then return end
        Refresh()
    end
end)

for _, event in ipairs({"ADDON_LOADED", "PLAYER_ENTERING_WORLD", "PLAYER_TARGET_CHANGED",
    "UNIT_COMBO_POINTS", "UNIT_AURA", "PLAYER_ALIVE", "PLAYER_DEAD", "PLAYER_LEVEL_UP", "PLAYER_LOGIN", "SPELLS_CHANGED"}) do
    driver:RegisterEvent(event)
end

-- Ascension's custom resources may change without a standard combo event.
local elapsed = 0
driver:SetScript("OnUpdate", function(self, delta)
    if not db then return end
    -- Keep checking class/enabled state even when the visible frame is hidden.
    -- Hidden characters skip aura scans and visual animation work.
    if not meter:IsShown() then
        elapsed = elapsed + delta
        if elapsed >= 0.25 then elapsed = 0; Refresh() end
        return
    end
    if preview then previewTime = previewTime + delta end
    pulseTime = pulseTime + delta
    gainTime = math.max(0, gainTime - delta)
    local glowAlpha = atFull and (0.56 + math.sin(pulseTime * 3) * 0.14) or (gainTime / 0.35) * 0.55
    for i = 1, MAX_POINTS do
        glows[i]:SetAlpha(i <= lastPoints and glowAlpha or 0)
    end
    elapsed = elapsed + delta
    if elapsed < 0.1 then return end
    elapsed = 0
    Refresh()
end)

SLASH_RANGERADVANTAGE1 = "/radv"
SLASH_RANGERADVANTAGE2 = "/rangeradvantage"
SlashCmdList.RANGERADVANTAGE = function(message)
    if not db then return end
    local command, argument = string.match(string.lower(message or ""), "^%s*(%S*)%s*(.-)%s*$")
    if command == "on" or command == "off" then
        db.enabled = command == "on"
        preview = false
        if not db.enabled then
            Say("Disabled. /radv on to enable again.")
        elseif IsRanger() then
            Say("Enabled.")
        else
            Say("Enabled, but hidden because this character is not a Ranger.")
        end
    elseif command == "lock" or command == "unlock" then
        SetLocked(command == "lock")
        Say(db.locked and "Locked. /radv unlock to move again." or "Unlocked. Left-drag to move.")
    elseif command == "reset" then
        db.point, db.relativePoint, db.x, db.y, db.scale = "CENTER", "CENTER", 0, -150, 1
        preview = false
        ApplyPosition()
        SetLocked(false)
        Say("Position and size reset; unlocked.")
    elseif command == "scale" then
        local scale = tonumber(argument)
        if scale and scale >= 0.5 and scale <= 3 then
            db.scale = scale
            ApplyPosition()
            Say("Scale: " .. scale)
        else Say("Use /radv scale 0.5 to 3 (example: /radv scale 1.3).") end
    elseif command == "test" then
        preview = not preview
        previewTime = 0
        Say(preview and "TEST mode: cycling 0-5. /radv test returns to live points." or "Live tracking restored.")
    elseif command == "status" then
        local points, source = ReadPoints()
        Say("Live: " .. points .. "; source: " .. source .. "; combo API: " .. (GetComboPoints("player", "target") or 0))
        local className, classToken, classID = UnitClass("player")
        Say("Class: " .. tostring(className) .. " / " .. tostring(classToken) .. " / " .. tostring(classID)
            .. "; enabled: " .. tostring(db.enabled) .. "; Ranger: " .. tostring(IsRanger()))
        Say("Advantage aura: " .. tostring(ReadAura()) .. "; test mode: " .. tostring(preview))
    else
        Say("/radv on | off | unlock | lock | reset | scale 1.3 | test | status")
    end
    Refresh()
end
